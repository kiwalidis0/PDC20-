import React from "react";
import "./ActChild.css";

function ActChild3(){
    return(
        <div className="container">
            <br></br>
            <label>
                Write a review:
                <input type="text" placeholder="Write a review"></input>
            </label>
        </div>
    );
}

export default ActChild3;