import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import LogAdmin from './Dashboard/LogAdmin';
import UserProfilePage from './Profile/UserProfile';
import AdminPanel from './Dashboard/AdminPanel';

function App() {
  return (
   <Router>
    <Routes>
      <Route path="/" element = {<LogAdmin/>}/>
      <Route path="/profile" element={<UserProfilePage/>}/>

    </Routes>
   </Router>
  );
}

export default App;