import React from "react";
import EventOnClick from "./EventonClick";
import KeyboardEvent from "./KeyboardEvent";
import MouseEvent from "./MouseEvent";
import ItemList from "./ItemList";
import './Item.css';


function MainEvent(){
    return(
        <div>
            {/**<EventOnClick/> */}
            {/**<KeyboardEvent/> */}
            {/**<MouseEvent/> */}
            <ItemList/>
        </div>
    )
}

export default MainEvent;