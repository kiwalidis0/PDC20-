import React from 'react';

function DisplaySum(){
    const num1= 10;
    const num2 = 20;
    return <h2>The sum of {num1} and {num2} is {num1 + num2}!</h2>

}

export default DisplaySum;