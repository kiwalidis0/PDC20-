import React from 'react';
import './UserProfile.css'

function Navagation(){
    return(
        <nav className='nav-list'>
            <ul>
                <li>Profile</li>
                <li>Settings</li>
                <li>Logout</li>
            </ul>
        </nav>
    );
}

export default Navagation;