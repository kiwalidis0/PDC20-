import React from "react";

function Child(){
    return(
        <div>
            <p>This is the child component</p>
        </div>
    );
}

export default Child;